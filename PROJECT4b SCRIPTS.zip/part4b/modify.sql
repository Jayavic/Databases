UPDATE customers
    -> SET
    -> customername = 'johnrose',
    -> customercontact = 'johnrose@gmail.com',
    -> numoforders = '3',
    -> customerstatus = 'inactive'
    -> WHERE
    -> customersid = 144;