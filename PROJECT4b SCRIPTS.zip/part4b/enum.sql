ALTER TABLE customers
ADD COLUMN customerstatus ENUM('active','inactive') NOT NULL;