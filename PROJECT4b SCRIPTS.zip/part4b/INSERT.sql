INSERT INTO customers (customersid,customername,customercontact,numoforders,customerstatus)
    -> VALUES (144,'rose','rose134@gmail.com',2,'active');