LOAD DATA INFILE 'C:/Users/arish/OneDrive/Desktop/newcsvfiles/rawmaterialsnewfile.csv' INTO TABLE rawma
terials FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n' IGNORE 1 ROWS (materialtype,source,quantity,
cost);