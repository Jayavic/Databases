LOAD DATA INFILE 'C:/Users/arish/OneDrive/Desktop/newcsvfiles/customernewfile.csv' INTO TABLE customers FI
ELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n' IGNORE 1 ROWS (customersid,customername,customercontact,n
umoforders);