CREATE TABLE housedesign (
    housetype VARCHAR(255),
    interiors VARCHAR(255),
    structure VARCHAR(255),
    quantity INT
);