CREATE TABLE customers (
    customerid INT,
    customername VARCHAR(255),
    customercontact VARCHAR(255),
    numoforders INT
);