CREATE TABLE orders (
    orderid INT,
    ordertype VARCHAR(255),
    quantity INT,
    budget FLOAT
);