CREATE TABLE employee (
    employeeid INT,
    employeename VARCHAR(255),
    salary FLOAT,
    roles VARCHAR(255)
);