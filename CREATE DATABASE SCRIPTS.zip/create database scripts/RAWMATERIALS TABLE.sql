CREATE TABLE rawmaterials (
    materialtype VARCHAR(255),
    source VARCHAR(255),
    quantity INT,
    cost Float
);